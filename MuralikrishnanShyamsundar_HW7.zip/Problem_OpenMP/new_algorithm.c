#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
#include <ctype.h>

int main (int argc, char *argv[])
{
    if( argc != 5)
    {
        printf("USE LIKE THIS: new_algorithm input_7.txt num_threads output_text.csv time.csv\n");
        return EXIT_FAILURE;
    }


    FILE *inputFile1;

    inputFile1 = fopen(argv[1], "r");

    int     thread_count;
    thread_count = strtol(argv[2], NULL, 10);

    FILE *outputFile;
    outputFile = fopen(argv[3], "w");

    FILE *outputTime;
    outputTime = fopen(argv[4], "w");

    long lSize;
    unsigned char *buffer;
    int asci;
    int alphabet_count[26]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

    /* Seek to the end of the file */
    fseek( inputFile1 , 0L , SEEK_END);
    lSize = ftell( inputFile1 );
    // printf("length file=%ld\n", lSize);
    rewind( inputFile1 );

    /* allocate memory for entire content */
    buffer = calloc( 1, lSize+1 );
    if( !buffer ) fclose(inputFile1),fputs("memory alloc fails",stderr),exit(1);

    /* copy the file into the buffer */
    if( 1!=fread( buffer , lSize, 1 , inputFile1) )
        fclose(inputFile1),free(buffer),fputs("entire read fails",stderr),exit(1);


    double start = omp_get_wtime();
    int i;

    #pragma omp parallel for num_threads(thread_count) shared(i,asci,buffer,alphabet_count)
    for (i=0;i<lSize+1;i++)
    {
        asci = (int)tolower(buffer[i]);
        if (asci>=97 && asci<=122)
        {
            #pragma omp critical
            alphabet_count[asci-97]=alphabet_count[asci-97]+1;
        }
    }

    double end = omp_get_wtime();

    char alphabet[26]={'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j','k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
	
    int j;
    for(j=0;j<26;j++)
    {
        fprintf(outputFile,"%c,%d\n",alphabet[j],alphabet_count[j]);

    }

    double time_passed = end - start;

    fprintf(outputTime, "%f", time_passed);

    return 0;
}
