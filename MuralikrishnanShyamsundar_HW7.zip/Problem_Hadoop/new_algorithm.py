from mrjob.job import MRJob
import string

class MRlettercount(MRJob):

    def mapper(self, _, line):
        line_punc = line.translate(str.maketrans('', '', string.punctuation))
        line_digits = line_punc.translate(str.maketrans('', '', string.digits))
        new_line = line_digits.replace(" ", "")
        word_dictionary = {}
        for cha in new_line:
            if cha.lower() in word_dictionary:
                word_dictionary[cha.lower()] += 1
            else:
                word_dictionary[cha.lower()] = 1

        for (key, local_value) in word_dictionary.items():
            yield (key, local_value)

    def reducer(self, key, values):
        yield (key, sum(values))


if __name__ == '__main__':
    MRlettercount.run()




