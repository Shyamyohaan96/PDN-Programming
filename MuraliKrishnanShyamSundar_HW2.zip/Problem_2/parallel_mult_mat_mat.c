#include <stdio.h>
#include <stdlib.h> // for strtol
#include <string.h>
#include <omp.h>


int main (int argc, char *argv[])
{
    if( argc != 10)
    {
        printf("USE LIKE THIS: parallel_mult_mat_mat file_1.csv n_row_1 n_col_1 file_2.csv n_row_2 n_col_2 num_threads results_matrix.csv time.csv\n");
        return EXIT_FAILURE;
    }

    FILE *inputFile1;
    FILE *inputFile2;

    char* p1;
    char* p2;
    int count_1 = 0;
    int count_2 = 0;
    int count_3 = 0;
    int count_4 = 0;
    char str[100000];
    char str2[100000];

    inputFile1 = fopen(argv[1], "r");

    int n_row1 = strtol(argv[2], &p1, 10 );
    int n_col1 = strtol(argv[3], &p2, 10 );

    double **input_arr_1 = (double**)malloc(n_row1*sizeof(double));
    for(int k = 0;k<n_row1;k++){
        input_arr_1[k]= (double*)malloc(n_col1*sizeof(double));
    }

    inputFile2 = fopen(argv[4], "r");

    int n_row2 = strtol(argv[5], &p1, 10 );
    int n_col2 = strtol(argv[6], &p2, 10 );

    double **input_arr_2 = (double**)malloc(n_row2*sizeof(double));
    for(int z = 0;z<n_row2;z++){
        input_arr_2[z]= (double*)malloc(n_col2*sizeof(double));
    }

    int     thread_count;
    thread_count = strtol(argv[7], NULL, 10);
    // printf("thread_count = %d\n", thread_count);

    FILE *outputFile;
    outputFile = fopen(argv[8], "w");

    double **output_arr = (double**)malloc(n_row1*sizeof(double));
    for(int s = 0;s<n_row1;s++){
        output_arr[s]= (double*)malloc(n_col2*sizeof(double));
    }

    FILE *outputTime;
    outputTime = fopen(argv[9], "w");

    while(fgets(str,sizeof(str), inputFile1)){
    char *token = strtok(str,",");
    while(token!=NULL){
        input_arr_1[count_1][count_2] = strtod(token, &token);
        token = strtok(NULL,",");
        count_2 = count_2+1;
    }
    count_1 = count_1+1;
    count_2 = 0;
    }

    while(fgets(str2,sizeof(str2), inputFile2)){
    char *tok = strtok(str2,",");
    while(tok!=NULL){
        input_arr_2[count_3][count_4] = strtod(tok, &tok);
        tok = strtok(NULL,",");
        count_4 = count_4+1;
    }
    count_3 = count_3+1;
    count_4 = 0;
    }


    // Start timing
    double start = omp_get_wtime();

    if(n_col1==n_row2){
    #pragma omp parallel for num_threads(thread_count)
    for (int a=0;a<n_row1;a++){
        for(int b=0;b<n_col2;b++){
                double temp =0.0;
                for (int c = 0;c<n_col1;c++){
                   temp = temp + (input_arr_1[a][c] * input_arr_2[c][b]);
                }
                output_arr[a][b] = temp;
        }

    }
    }

    double end = omp_get_wtime();

    // Time calculation (in seconds)

    double time_passed = end - start;

    // save time to file
    fprintf(outputTime, "%f", time_passed);

    for (int y=0;y<n_row1;y++){
        for (int h = 0;h<n_col2;h++){
           fprintf(outputFile,"%lf,",output_arr[y][h]);
        }
        fprintf(outputFile,"\n");
}

    fclose (inputFile1);
    fclose (inputFile2);
    fclose (outputFile);
    fclose (outputTime);

    return 0;
}

