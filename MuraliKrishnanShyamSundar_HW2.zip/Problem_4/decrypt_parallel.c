#include <stdio.h>
#include <stdlib.h> // for strtol
#include <string.h>
#include <omp.h>

int main (int argc, char *argv[])
{
    if( argc != 4)
    {
        printf("USE LIKE THIS: encrypt_parallel key input_text.txt num_threads output_text.txt time.txt\n");
        return EXIT_FAILURE;
    }

    char* p1;


    int     thread_count;
    thread_count = strtol(argv[2], NULL, 10);

    FILE *out_file;
    out_file = fopen(argv[3], "w");

    int poss_count = 0;
    int poss_key = 0;

    #pragma omp parallel for num_threads(thread_count)
    for(int i =1;i<256;i++)
    {
       FILE * the_file = fopen(argv[1], "r");;
       FILE * decrp_file = fopen("decrypt.txt", "w");
       char str[1000000];
       while(fgets(str, sizeof(str), the_file))
       {
           for (int j=0;str[j]!= '\0';j++)
            {
               int asc = (int)str[j];
               int decrp_num = (asc-i)%256;
               str[j] = (char)decrp_num;
            }
            fputs(str,decrp_file);
       }
       fclose(decrp_file);

       FILE *d_file = fopen("decrypt.txt", "r");
       char str2[1000000];
       int count = 0;
       while(fgets(str2,sizeof(str2),d_file))
       {
           char *token = strtok(str2," ");
           while(token!=NULL)
           {
               if (strcmp(token,"the")==0 || strcmp(token,"The")==0)
               {
                   count = count +1;
               }
               token = strtok(NULL," ");
           }
       }
       #pragma omp critical
       if(count > poss_count)
       {
           poss_count = count;
           poss_key = i;

       }
       fclose(d_file);
       fclose(the_file);
       remove("decrypt.txt");
    }

    fprintf(out_file,"The key required for decrypting the file is %d", poss_key);

    fclose(out_file);
    return 0;
}
