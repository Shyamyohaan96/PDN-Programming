#include <stdio.h>
#include <stdlib.h> // for strtol
#include <string.h>
#include <omp.h>
#include <math.h> // pow

#define MAXCHAR 25

int main (int argc, char *argv[])
{
    if( argc != 8)
    {
        printf("USE LIKE THIS: kmeans_parallel n_points points.csv num_threads n_centroids initial_centroid_values.csv final_centroid_values.csv time.csv\n");
        return EXIT_FAILURE;
    }

    omp_lock_t my_lock;
    omp_init_lock(&my_lock);

    int n_points;
    n_points = strtol(argv[1], NULL, 10);

    double* array_x;
    double* array_y;

    double* array_centroid_x;
    double* array_centroid_y;

    int* cluster_array;

    FILE *inputFile1;
    FILE *inputFile2;

    char* p1;
    char* p2;

    inputFile1 = fopen(argv[2], "r");
    if (inputFile1 == NULL){
        printf("Could not open file %s",argv[2]);
    }

    int thread_count;
    thread_count = strtol(argv[3], NULL, 10);

    int n_centroids;
    n_centroids = strtol(argv[4], NULL, 10);

    inputFile2 = fopen(argv[5], "r");
    if (inputFile2 == NULL){
        printf("Could not open file %s",argv[5]);
    }

    FILE *outputFile;
    outputFile = fopen(argv[6], "w");

    FILE *outputFile2;
    outputFile2 = fopen(argv[7], "w");

    char str[MAXCHAR];
    double average_dist = 1000000.00;

    array_x = malloc(n_points*sizeof(double));
    array_y = malloc(n_points*sizeof(double));

    array_centroid_x = malloc(n_centroids*sizeof(double));
    array_centroid_y = malloc(n_centroids*sizeof(double));

    cluster_array = malloc(n_points*sizeof(int));


    // Store values of 2D points
    int k = 0;
    while (fgets(str, MAXCHAR, inputFile1) != NULL)
    {
        sscanf( str, "%lf,%lf", &(array_x[k]), &(array_y[k]) );
        k++;
    }
    fclose(inputFile1);

    // Storing centroid values
    k = 0;

    while (fgets(str, MAXCHAR, inputFile2) != NULL)
    {
        sscanf( str, "%lf,%lf", &(array_centroid_x[k]), &(array_centroid_y[k]) );
        k++;
    }

    fclose(inputFile2);

    double start = omp_get_wtime();

    #pragma omp parallel num_threads(thread_count) default(none) shared(my_lock,array_x,array_y,array_centroid_x,array_centroid_y,cluster_array, average_dist,n_points,n_centroids)
    {
    while (average_dist>1.0)
    {
	#pragma omp barrier
	#pragma omp single
        average_dist = 0.0;

        #pragma omp for schedule(guided)
        for(int i=0;i<n_points;i++)
        {
           double min_distance = 1000000.00;
           double distance = 0.0;
           for(int j=0;j<n_centroids;j++)
           {
                distance = pow(pow(array_x[i]-array_centroid_x[j],2.0) + pow(array_y[i]-array_centroid_y[j],2.0),0.5);
                if (distance<min_distance)
                {
                    min_distance= distance;
		   #pragma omp critical
                    cluster_array[i] = j+1;
                }
           }
        }

        #pragma omp for schedule(static,1)
        for(int a=0;a<n_centroids;a++)
        {
            double temp_1 = 0.0;
            double temp_2 = 0.0;
            double count = 0.0;
            double temp_x = 0.0;
            double temp_y = 0.0;
            for (int b=0;b<n_points;b++)
            {
                if (cluster_array[b]==a+1)
                {
                    temp_1 = temp_1+ array_x[b];
                    temp_2 = temp_2+ array_y[b];
                    count=count + 1;
                }

            }

            if (count >  0.0)
            {
                temp_x = temp_1/count;
                temp_y = temp_2/count;
            }

            if (count == 0.0)
            {
                temp_x = array_centroid_x[a];
                temp_y = array_centroid_y[a];
            }
            omp_set_lock(&my_lock);
            average_dist = average_dist+  pow(pow(temp_x-array_centroid_x[a],2.0) + pow(temp_y-array_centroid_y[a],2.0),0.5);
            omp_unset_lock(&my_lock);
            array_centroid_x[a]= temp_x;
            array_centroid_y[a] = temp_y;


     	}
	#pragma omp single
        average_dist = average_dist/n_centroids;
    }
    }
    omp_destroy_lock(&my_lock);
    double end = omp_get_wtime();

    // Time calculation (in seconds)

    double time_passed = end - start;

    for (int c =0; c<n_centroids;c++)
    {
        fprintf(outputFile,"%lf,%lf", array_centroid_x[c],array_centroid_y[c]);
        fprintf(outputFile,"\n");

    }

    fprintf(outputFile2, "%f", time_passed);

    fclose (outputFile);
    fclose (outputFile2);

    free(array_x);
    free(array_y);
    free(array_centroid_x);
    free(array_centroid_y);

    return 0;
}


