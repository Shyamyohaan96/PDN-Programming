#include <stdio.h>
#include <stdlib.h> // for strtol
#include <string.h>
#include <omp.h>
#include <math.h> // pow

#define MAXCHAR 25

int main (int argc, char *argv[])
{
    if( argc != 6)
    {
        printf("USE LIKE THIS: new_algoirthm size input.csv num_threads  final.csv time.csv\n");
        return EXIT_FAILURE;
    }

    int si;
    si = strtol(argv[1], NULL, 10);
    FILE *inputFile1;

    inputFile1 = fopen(argv[2], "r");
    if (inputFile1 == NULL){
        printf("Could not open file %s",argv[2]);
    }

    int thread_count;
    thread_count = strtol(argv[3], NULL, 10);

    FILE *outputFile1;
    FILE *outputFile2;

    outputFile1 = fopen(argv[4], "w");
    outputFile2 = fopen(argv[5], "w");

    char str[MAXCHAR];
    int* arr;

    arr = malloc(si*sizeof(int));

    int k = 0;
    while (fgets(str, MAXCHAR, inputFile1) != NULL)
    {
        sscanf( str, "%d", &(arr[k]) );
        k++;
    }
    fclose(inputFile1);
   
    int hal = sizeof(arr)/sizeof(arr[0]);

   int max_till = 0;
   int max_end = 0;
    double start = omp_get_wtime();
    #pragma omp parallel for num_threads(thread_count) default(none) shared(arr,max_end,si,hal) private(max_till)
    for (int i=0;i<hal;i++)
    {
	max_end = max_end+arr[i];
        if(max_till< max_end)
            max_till = max_end;
        if(max_end<0)
            max_end = 0;
    }
    double end = omp_get_wtime();

    double time_passed = end - start;

    fprintf(outputFile1,"%d", max_till);
    fprintf(outputFile2, "%f", time_passed);

    fclose (outputFile1);
    fclose (outputFile2);
    return 0;
}
