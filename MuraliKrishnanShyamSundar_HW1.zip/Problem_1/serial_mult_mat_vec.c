#include <stdio.h>
#include <stdlib.h>
#include<string.h>


int main (int argc, char *argv[])
{
    if( argc != 7)
    {
        printf("USE LIKE THIS: serial_mult_mat_vec file_1.csv n_row_1 n_col_1 file_2.csv n_row_2 outputfile.csv \n");
        return EXIT_FAILURE;
    }

    int count_1 = 0;
    int count_2 = 0;
    int count = 0;
    char str[100000];
    char str2[1000];


    FILE *inputFile1;
    FILE *inputFile2;

    char* p1;
    char* p2;

    inputFile1 = fopen(argv[1], "r");

    int n_row1 = strtol(argv[2], &p1, 10 );
    int n_col1 = strtol(argv[3], &p2, 10 );

    double **input_arr = (double**)malloc(n_row1*sizeof(double));
    for(int k = 0;k<n_row1;k++)
    {
        input_arr[k]= (double*)malloc(n_col1*sizeof(double));
    }


    while(fgets(str,sizeof(str), inputFile1))
    {
    char *token = strtok(str,",");
    while(token!=NULL)
    {
        input_arr[count_1][count_2] = strtod(token, &token);
        token = strtok(NULL,",");
        count_2 = count_2+1;
    }
    count_1 = count_1+1;
    count_2 = 0;
    }

    printf("The input matrix is: \n");
for(int i = 0; i<n_row1; i++){
        for(int j = 0; j<n_col1; j++){
            printf("%lf\t", input_arr[i][j]);
        }
        printf("\n");
}


    inputFile2 = fopen(argv[4], "r");

    char* p3;
    int n_row2 = strtol(argv[5], &p3, 10 );

    double* input_vec = (double*)malloc(n_row2*sizeof(double));

    while(fgets(str2,sizeof(str2),inputFile2))
    {
    char *tok = strtok(str2,",");
    input_vec[count] = strtod(tok, &tok);
    count = count+1;
    }


    FILE *outputFile;
    outputFile = fopen(argv[6], "w");

    double* output_vec = (double*)malloc(n_row2*sizeof(double));

    if(n_col1==n_row2)
    {
    for (int a=0;a<n_row1;a++)
    {
        int temp =0;
        for(int b=0;b<n_col1;b++)
        {
            temp = temp + (input_arr[a][b] * input_vec[b]);
        }
        output_vec[a] = temp;
    }
    }

    for (int y=0;y<n_row2;y++)
    {
    fprintf(outputFile,"%f\n",output_vec[y]);
    }

    fclose (inputFile1);
    fclose (inputFile2);
    fclose (outputFile);

    return 0;
}
