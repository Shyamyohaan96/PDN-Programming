from mrjob.job import MRJob
import re

word_r = re.compile(r"[\w']+")

class MRLongestWords(MRJob):

    def mapper(self, _, line):
        alpha = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        word_dictionary = {}
        for alphabet in alpha:
            li=[]
            li_2=[]
            for words in word_r.findall(line):
                if alphabet == words.lower()[0] and words.lower() not in li:
                    li.append(words.lower())
            if len(li) != 0:
                malen = len(max(li, key=len))
                li_2 = [a for a in li if len(a) == malen]
            word_dictionary[alphabet] = li_2
        for (key, local_value) in word_dictionary.items():
            yield (key, local_value)

    def reducer(self, key, values):
        malen =0
        values = list(values)
        for sub in values:
            if len(sub) != 0:
                local_malen = len(max(sub, key=len))
                malen = max(local_malen,malen)

        li_2 = []
        for sub in values:
            if len(sub) !=0:
                local_malen = len(max(sub, key = len))
                if(local_malen == malen):
                    li_2.extend(sub)
        final_list = list(dict.fromkeys(li_2))
        yield (key, final_list)


if __name__ == '__main__':
    MRLongestWords.run()



