from socket import *
import re

needed_ip= re.compile(r"^(\d+)(,\s*\d+)*$")

serverSocket = socket(AF_INET, SOCK_DGRAM)

serverIP = '127.0.0.1'
serverPort = 12345
serverAddress = (serverIP, serverPort)
serverSocket.bind(serverAddress)
print('The server is ready to receive')

while True:
    messageBytes, clientAddress = serverSocket.recvfrom(2048)
    clientIP, clientPort = clientAddress
    message = messageBytes.decode("utf-8")
    print(f'message from {clientIP}:{clientPort} = {message}')


    if needed_ip.match(message) is not None:
        li = message.split(",")
        li_2 = []
        for i in li:
            li_2.append(float(i))

        product = 1
        for j in li_2:
            product = product*j

        modifiedMessage = str(product)
        serverSocket.sendto(modifiedMessage.encode("utf-8"), clientAddress)
    else:
        modifiedMessage = "invalid input"
        serverSocket.sendto(modifiedMessage.encode("utf-8"), clientAddress)

