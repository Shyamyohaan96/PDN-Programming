from socket import *

clientSocket = socket(AF_INET, SOCK_STREAM)

clientSocket.bind(('', 10000))

message = input('Enter the numbers(comma separated):')

messageBytes = message.encode("utf-8")

serverIP = '127.0.0.1'
serverPort = 12345
serverAddress = (serverIP, serverPort)
clientSocket.connect(serverAddress)

clientSocket.send(messageBytes)

modifiedMessageBytes = clientSocket.recv(1024)
print('From Server: ', modifiedMessageBytes.decode("utf-8"))
clientSocket.close()

