from socket import *

clientSocket = socket(AF_INET, SOCK_DGRAM)

clientSocket.bind(('', 10000))

message = input('Enter the numbers(comma separated):')

messageBytes = message.encode("utf-8")

serverIP = '127.0.0.1'
serverPort = 12345
serverAddress = (serverIP, serverPort)
clientSocket.sendto(messageBytes, serverAddress)

modifiedMessageBytes, serverAddress = clientSocket.recvfrom(2048)
modifiedMessage = modifiedMessageBytes.decode("utf-8")
serverIP, serverPort = serverAddress
print(f'message from {serverIP}:{serverPort} = {modifiedMessage}')
clientSocket.close()


