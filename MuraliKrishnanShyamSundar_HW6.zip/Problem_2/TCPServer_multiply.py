from socket import *
import re

needed_ip= re.compile(r"^(\d+)(,\s*\d+)*$")

serverSocket = socket(AF_INET, SOCK_STREAM)

serverIP = '127.0.0.1'
serverPort = 12345
serverAddress = (serverIP, serverPort)
serverSocket.bind(serverAddress)

serverSocket.listen(1)

print('The server is ready to receive')

while True:
    connectionSocket, clientAddress = serverSocket.accept()
    clientIP, clientPort = clientAddress
    messageBytes = connectionSocket.recv(1024)
    message = messageBytes.decode("utf-8")
    print(f'message from {clientIP}:{clientPort} = {message}')

    if needed_ip.match(message) is not None:
        li = message.split(",")
        li_2 = []
        for i in li:
            li_2.append(float(i))

        product = 1
        for j in li_2:
            product = product*j

        modifiedMessage = str(product)
        connectionSocket.send(modifiedMessage.encode("utf-8"))
    else:
        modifiedMessage = "invalid input"
        connectionSocket.send(modifiedMessage.encode("utf-8"))

    connectionSocket.close()


